/*
	S10Q2 Q2) Write a program to create a package name student.
	Define class StudentInfo with method to display information about
	student such as rno,sname class, and percentage. Create another class
	StudentPer with method to find percentage of the student.
	Accept student details like rollno, name, class and marks of 6 subject
	from user.[20 marks]
*/

import java.util.Scanner;
//import student.StudentInfo;
//import student.StudentPer;
import student.*;

public class S10Q2_StudPack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Roll No: ");
        int rno = sc.nextInt();
        sc.nextLine(); // consume newline

        System.out.print("Enter Name: ");
        String sname = sc.nextLine();

        System.out.print("Enter Class: ");
        String sclass = sc.nextLine();

        int marks[] = new int[6];
        System.out.println("Enter marks of 6 subjects:");
        for (int i = 0; i < 6; i++) {
            System.out.print("Subject " + (i + 1) + ": ");
            marks[i] = sc.nextInt();
        }

        StudentPer sp = new StudentPer();
        double per = sp.calculatePercentage(marks);

        StudentInfo si = new StudentInfo(rno, sname, sclass, per);

        si.displayInfo();

        //sc.close();
    }
}