/*
Q1) Write a program to find the cube of given number using functional
interface.[10 marks]
*/
// Functional Interface
@FunctionalInterface
interface Cube {
    int findCube(int n);
}

public class S10Q1_FunInterf_FindCube {
    public static void main(String[] args) {
        // Lambda expression for cube
        Cube c = (n) -> n * n * n;

        int num = 4;
        System.out.println("Cube of " + num + " = " + c.findCube(num));
    }
}
