/*
	Q1) Write a program to accept a file name from command prompt, if the file
	exits then display number of words and lines in that file.[10 marks]
*/
import java.io.*;
import java.util.StringTokenizer;

public class S13Q1_FileCmdCountWordLine {
    public static void main(String[] args) {

        String fName = args[0];
        File f = new File(fName);

        int lineCount = 0, wordCount = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineCount++;

                // Split words using StringTokenizer
                StringTokenizer st = new StringTokenizer(line);
                wordCount = wordCount + st.countTokens();
            }

            System.out.println("File Name: " + fName);
            System.out.println("Number of Lines: " + lineCount);
            System.out.println("Number of Words: " + wordCount);

        } catch (IOException e) {
            System.out.println("Error : " + e.getMessage());
        }
    }
}

