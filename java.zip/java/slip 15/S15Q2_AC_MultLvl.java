/*
S15Q2 Q2) Write a program to define a class Account having members
custname, accno. Define default and parameterized constructor.
Create a subclass called SavingAccount with member savingbal,minbal.
Create a derived class AccountDetail that extends the class SavingAccount
with members, depositamt and withdrawalamt.
Write a appropriate method to display customerdetails.[20 marks]
*/
import java.util.Scanner;

// Base Class
class Account {
    String cname;
    int ano;

    Account() {
        this.cname = "Unknown";
        this.ano = 0;
    }

    Account(String cname, int ano) {
        this.cname = cname;
        this.ano = ano;
    }
}

// Derived Class 1
class SavingAccount extends Account {
    double savbal;
    double minbal;

    SavingAccount(String cname, int ano, double savbal, double minbal) {
        super(cname, ano);
        this.savbal = savbal;
        this.minbal = minbal;
    }
}

// Derived Class 2 (Multilevel)
class AccountDetail extends SavingAccount {

    AccountDetail(String cname, int ano, double savbal, double minbal) {
        super(cname, ano, savbal, minbal);
    }

    // Deposit
    void deposit(double amt) {
        //if (amt > 0) {
            savbal = savbal + amt;
            System.out.println("Deposited: " + amt);
        //} else {
            //System.out.println("Invalid deposit amount!");
        //}
    }

    // Withdraw
    void withdraw(double amt) {
        if (amt > 0) {
            if ((savbal - amt) >= minbal) {
                savbal =savbal - amt;
                System.out.println("Withdrawn: " + amt);
            } else {
                System.out.println("Withdrawal not allowed. Minimum balance must be maintained.");
            }
        } else {
            System.out.println("Invalid withdraw amount!");
        }
    }

    // Display
    void displayDetails() {
        System.out.println("\n===== Account Details =====");
        System.out.println("Customer Name : " + cname);
        System.out.println("Account No    : " + ano);
        System.out.println("Balance       : " + savbal);
        System.out.println("Minimum Bal   : " + minbal);
    }
}

public class S15Q2_AC_MultLvl {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        AccountDetail acc = null;
        int ch=0;

        while (ch != 5) {
            System.out.println("\n===== MENU =====");
            System.out.println("1. Enter Customer Details");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Display Details");
            System.out.println("5. Exit");
            System.out.print("Enter your ch: ");
            ch = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (ch) {
                case 1:
                    System.out.print("Enter Customer Name: ");
                    String cname = sc.nextLine();

                    System.out.print("Enter Account Number: ");
                    int ano = sc.nextInt();

                    System.out.print("Enter Saving Balance: ");
                    double savbal = sc.nextDouble();

                    System.out.print("Enter Minimum Balance: ");
                    double minbal = sc.nextDouble();

                    acc = new AccountDetail(cname, ano, savbal, minbal);
                    System.out.println("Customer details added successfully!");
                    break;

                case 2:
                    if (acc != null) {
                        System.out.print("Enter Deposit Amount: ");
                        double damt = sc.nextDouble();
                        acc.deposit(damt);
                    } else {
                        System.out.println("Please enter customer details first!");
                    }
                    break;

                case 3:
                    if (acc != null) {
                        System.out.print("Enter Withdraw Amount: ");
                        double wamt = sc.nextDouble();
                        acc.withdraw(wamt);
                    } else {
                        System.out.println("Please enter customer details first!");
                    }
                    break;

                case 4:

                        acc.displayDetails();

                    break;

                case 5:
                    System.out.println("Exiting... Thank you!");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
        sc.close();
    }
}


/*
===== MENU =====
1. Enter Customer Details
2. Deposit
3. Withdraw
4. Display Details
5. Exit
Enter your ch: 1
Enter Customer Name: Ramesh
Enter Account Number: 101
Enter Saving Balance: 5000
Enter Minimum Balance: 1000
Customer details added successfully!

===== MENU =====
2. Deposit
Enter Deposit Amount: 2000
Deposited: 2000

===== MENU =====
3. Withdraw
Enter Withdraw Amount: 3000
Withdrawn: 3000

===== MENU =====
4. Display Details
===== Account Details =====
Customer Name : Ramesh
Account No    : 101
Balance       : 4000.0
Minimum Bal   : 1000.0
*/