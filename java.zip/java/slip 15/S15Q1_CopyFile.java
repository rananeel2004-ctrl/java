/*
S15Q1) Accept the names of two files and copy the contents of the first to the
second. First file having Book name and Author name in file.[10 marks]
*/

import java.io.FileReader;
import java.io.FileWriter;

public class S15Q1_CopyFile {
    public static void main(String[] args) {
        try {
            FileReader fr = new FileReader("src.txt");
            FileWriter fw = new FileWriter("dest.txt");

            int i;
            while ((i = fr.read()) != -1) {
                fw.write(i);  // write character by character
            }

            fr.close();
            fw.close();
            System.out.println("File copied successfully.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}