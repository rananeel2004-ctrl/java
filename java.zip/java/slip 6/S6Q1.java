/*
S6Q1 Q1) Write a program to display the
Employee(Empid, Empname, Empdesignation, Empsal) information using toString().
*/
import java.util.*;

class Employee
{
	int eid=0;
	String ename="",edesig="";
	double esal=0.0;
	Scanner sc = new Scanner(System.in);
	Employee(int eid,String sn,String edes,double es)
	{
		this.eid=eid;
		ename=sn;
		edesig=edes;
		esal=es;
	}
	public String toString()
	{
		return("Empid - "+eid+"\tName - "+ename+"\tDesignation - "+edesig+"\tSal - "+esal);
	}
}
class S6Q1
{
	public static void main(String s[])
	{
		Employee e = new Employee(101,"Rajesh","Manager",50000.00);
		System.out.println("The Details of Employee is\n"+e);
	}
}