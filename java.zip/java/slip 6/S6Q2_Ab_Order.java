/* S6Q2
	Q2) Create an abstract class �order� having members id, description.
	Create two sub classes �Purchase Order� and �Sales Order� having members
	customer name and Vendor name respectively. Define methods accept and
	display in all cases. Create 3 objects each of PurchaseOrder and Sales
	Order and accept and display details.[20 marks]
*/

import java.util.Scanner;

abstract class Order {
    int oid;
    String odesc;

    abstract void accept();
    abstract void display();
}

class PurchaseOrder extends Order {
    String cname;
	Scanner sc = new Scanner(System.in);
    void accept() {
        System.out.print("Enter Order Id: ");
        oid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Order Description: ");
        odesc = sc.nextLine();
        System.out.print("Enter Customer Name: ");
        cname = sc.nextLine();
    }

    void display() {
        System.out.println("Purchase Order -> Id: " + oid + ", Desc: " +
        odesc + ", Customer: " + cname);
    }
}

class SalesOrder extends Order {
    String vname;
	Scanner sc = new Scanner(System.in);
    void accept() {
        System.out.print("Enter Order Id: ");
        oid = sc.nextInt();
        sc.nextLine();
        System.out.print("Enter Order Description: ");
        odesc = sc.nextLine();
        System.out.print("Enter Vendor Name: ");
        vname = sc.nextLine();
    }

    void display() {
        System.out.println("Sales Order -> Id: " + oid + ", Desc: " +
        odesc + ", Vendor: " + vname);
    }
}

public class S6Q2_Ab_Order {
    public static void main(String[] args) {
        //Scanner sc = new Scanner(System.in);

        // Create 3 purchase orders
        PurchaseOrder[] porders = new PurchaseOrder[3];
        for (int i = 0; i < 3; i++) {
            System.out.println("\nEnter details for Purchase Order " +
            (i + 1));
            porders[i] = new PurchaseOrder();
            porders[i].accept();
        }

        // Create 3 sales orders
        SalesOrder[] sorders = new SalesOrder[3];
        for (int i = 0; i < 3; i++) {
            System.out.println("\nEnter details for Sales Order " + (i + 1));
            sorders[i] = new SalesOrder();
            sorders[i].accept();
        }

        System.out.println("\n===== Purchase Orders =====");
        //for (PurchaseOrder po : porders) {
		for(int i=0;i<porders.length;i++)
        {
            porders[i].display();
        }

        System.out.println("\n===== Sales Orders =====");
        //for (SalesOrder so : sorders)
        for(int i=0;i<sorders.length;i++)
        {
            sorders[i].display();
        }

    }
}