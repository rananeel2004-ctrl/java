/*S11Q1
	Q1) Define an interface �Operation� which has method volume().Define a
	constant PI having a value 3.142 Create a class cylinder which implements
	this interface (members � radius, height). Create one object and calculate
	the volume.[10 marks]
*/

// Define interface
interface Operation
{
    final double PI = 3.142; // Constant value
    double volume();   // abstract method
    //void print();
}

// Implementing class
class Cylinder implements Operation {
    double rd, ht;

    Cylinder(double r, double h) {
        rd = r;
        ht = h;
    }

    // Implement volume()
    public double volume() {
        return PI * rd * rd * ht;
    }

}

public class S11Q1_Interf_Operation {
    public static void main(String[] args) {
        Cylinder c = new Cylinder(5, 10);
        System.out.println("Volume of Cylinder = " + c.volume());
    }
}