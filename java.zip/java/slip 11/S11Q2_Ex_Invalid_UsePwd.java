/*
S11Q2 Q2) Write a program to accept the username and password from user if
username and password are not same then raise "Invalid Password" with
appropriate msg.[20 marks]
*/

import java.util.Scanner;

class InvalidPWDEx extends Exception {
    InvalidPWDEx(String msg) {
        super(msg);
    }
}

public class S11Q2_Ex_Invalid_UsePwd {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Username: ");
        String uname = sc.nextLine();

        System.out.print("Enter Password: ");
        String pwd = sc.nextLine();

        try {
            if (!uname.equals(pwd)) {
                throw new InvalidPWDEx("Invalid Password! Username and Password must match.");
            } else {
                System.out.println("? Login Successful!");
            }
        } catch (InvalidPWDEx e) {
            System.out.println("Exception: " + e.getMessage());
        }

        sc.close();
    }
}