import java.util.Scanner;

class CricketPlayer {
    String name;
    int no_of_in;
    int no_of_tm_notout;
    int tot_runs;
    double bat_avg;

    CricketPlayer(String name, int innings, int notout, int runs)
    {
        this.name = name;
        this.no_of_in = innings;
        this.no_of_tm_notout = notout;
        this.tot_runs = runs;
        this.bat_avg = 0.0;
    }

    public static void avg(CricketPlayer p) {
        int tot_out = p.no_of_in - p.no_of_tm_notout;
        if (tot_out > 0)
            p.bat_avg = (double) p.tot_runs / tot_out;
        else
            p.bat_avg = p.tot_runs; // if never out, average = total runs
    }

    // Static method to sort p by batting average (descending)
    public static void sort(CricketPlayer cp[]) {
        for (int i = 0; i < cp.length - 1; i++) {
            for (int j = i + 1; j < cp.length; j++) {
                if (cp[i].bat_avg < cp[j].bat_avg) {
                    // swap
                    CricketPlayer temp = cp[i];
                    cp[i] = cp[j];
                    cp[j] = temp;
                }
            }
        }
    }
	public void display()
	{
        System.out.println(name + "\t" + no_of_in + "\t" + no_of_tm_notout + "\t" + tot_runs + "\t" + bat_avg);
    }
}

public class S2Q2 {
    public static void main(String[] args) {
		String name = "";
		int n = 0,i=0,innings = 0,notout = 0,runs = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number of Player: ");
        n = sc.nextInt();
        sc.nextLine();

        CricketPlayer p[] = new CricketPlayer[n];

        for (i = 0; i < n; i++) {
            System.out.println("\nEnter details for player " + (i + 1));
            System.out.print("Name: ");
            name = sc.nextLine();
            System.out.print("Number of innings: ");
            innings = sc.nextInt();
            System.out.print("Number of times not out: ");
            notout = sc.nextInt();
            System.out.print("Total runs: ");
            runs = sc.nextInt();
            sc.nextLine(); // consume newline

            p[i] = new CricketPlayer(name, innings, notout, runs);
            CricketPlayer.avg(p[i]); // calculate average
        }

        // Sort p based on batting average
        CricketPlayer.sort(p);

        // Display sorted details
        System.out.println("\nPlayer Details in Sorted Order (by Batting Average):");
        System.out.println("Name\tInnings\tNotOut\tRuns\tAverage");
        for (i = 0; i < n; i++)
            p[i].display();
    }
}
