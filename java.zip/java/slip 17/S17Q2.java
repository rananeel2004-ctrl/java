/*
Write Java program to design three text boxes and two buttons using swing. Enter different
strings in first and second textbox. On clicking the First command button, concatenation of
two strings should be displayed in third text box and on clicking second command button,
reverse of string should display in third text box

*/

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class myFrame extends JFrame implements ActionListener
{
	JTextField t1,t2,t3;
	JButton b1, b2;

    myFrame() {
        setVisible(true);
        setSize(500, 500);


         t1 = new JTextField(10);
         t2 = new JTextField(10);
         t3 = new JTextField(30);

		 b1 = new JButton("Concate");
		 b2 = new JButton("Rev");

		 setLayout(new FlowLayout());

		 add(t1);add(t2); add(t3);
		 add(b1);add(b2);

		 b1.addActionListener(this);
		 b2.addActionListener(this);
    }
    public void actionPerformed(ActionEvent e)
    {
		String str1 = t1.getText();
		String str2 = t2.getText();
		StringBuffer sb = new StringBuffer(str1);
		if(e.getSource()==b1)
		{
			t3.setText(str1+str2);
		}
		if(e.getSource()==b2)
		{

			String revstr = "";
			revstr = ""+sb.reverse();
			t3.setText(revstr);
		}
	}
}

public class S17Q2 {
    public static void main(String[] args) {
        new myFrame();
    }
}
