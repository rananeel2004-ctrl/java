/* S17Q1_CustDepoBorr_multLvl
 Q1) Design a Super class Customer (name, phone-number).
 Derive a class Depositor(accno , balance)from Customer.
 Again, derive a class Borrower (loan-no, loan-amt) from Depositor.
 Write necessary member functions to read and display the details of
 �n�customers.[10 marks]
*/

import java.util.Scanner;

// Superclass
class Customer {
    String cname;
    String cPhNo;

    void read(Scanner sc) {
        System.out.print("Enter Customer Name: ");
        cname = sc.nextLine();
        System.out.print("Enter Phone Number: ");
        cPhNo = sc.nextLine();
    }

    void display() {
        System.out.println("Customer Name : " + cname);
        System.out.println("Phone Number  : " + cPhNo);
    }
}

// Derived class 1
class Depositor extends Customer {
    int aNo;      // Account Number
    double bal;   // Balance

    void read(Scanner sc) {
        super.read(sc);
        System.out.print("Enter Account Number: ");
        aNo = sc.nextInt();
        System.out.print("Enter Balance: ");
        bal = sc.nextDouble();
        sc.nextLine(); // consume newline
    }

    void display() {
        super.display();
        System.out.println("Account No    : " + aNo);
        System.out.println("Balance       : " + bal);
    }
}

// Derived class 2 (Multilevel)
class Borrower extends Depositor {
    int lNo;      // Loan Number
    double lamt;  // Loan Amount

    void read(Scanner sc) {
        super.read(sc);
        System.out.print("Enter Loan Number: ");
        lNo = sc.nextInt();
        System.out.print("Enter Loan Amount: ");
        lamt = sc.nextDouble();
        sc.nextLine(); // consume newline
    }

    void display() {
        super.display();
        System.out.println("Loan No       : " + lNo);
        System.out.println("Loan Amount   : " + lamt);
    }
}

public class S17Q1_CustDepoBorr_multLvl {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of customers: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        Borrower customers[] = new Borrower[n];

        // Read details
        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details of Customer " + (i + 1));
            customers[i] = new Borrower();
            customers[i].read(sc);
        }

        // Display details
        System.out.println("\n===== Customer Details =====");
        for (int i = 0; i < n; i++) {
            System.out.println("\n--- Customer " + (i + 1) + " ---");
            customers[i].display();
        }

        sc.close();
    }
}


