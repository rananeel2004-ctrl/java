/*S5Q2
Q2) Write a menu driven program to perform the following operations on
multidimensional arrayie matrices :1.Addition 2.Multiplication 3.Exit
*/
import java.util.Scanner;


class MatOp {
	int a[][]=new int [3][3],b[][]=new int [3][3],c[][]=new int [3][3];
	int i=0,j=0,k=0;
	Scanner sc = new Scanner(System.in);
    void readMatrix()
    {
		System.out.print("Enter elements for 3X3 Matrix A ");
		for (i = 0; i < 3; i++)
		{
			for (j = 0; j < 3; j++)
				a[i][j] = sc.nextInt();
		}

		System.out.print("Enter elements for 3X3 Matrix B ");
		for (i = 0; i < 3; i++)
		{
			for (j = 0; j < 3; j++)
				b[i][j] = sc.nextInt();
		}
	}

	void matadd()
	{
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
					c[i][j] = a[i][j] + b[i][j];
			}
        }

        dispmat(c);
	}
	void matMult()
	{
		for (int i = 0; i < 3; i++) {
		            for (int j = 0; j < 3; j++) {
		                for (int k = 0; k < 3; k++) {
		                    c[i][j] = c[i][j]+ a[i][k] * b[k][j];
		                }
		            }
        }
        dispmat(c);
	}
	void dispmat(int c[][]) {
		for (i = 0; i < 3; i++) {
			System.out.println("");
				for (j = 0; j < 3; j++)
					System.out.print(" "+c[i][j]);
		}
    }

}
class S5Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        MatOp mo = new MatOp();

        int ch=0;
        while (ch!= 3){
            System.out.println("\n--- Matrix Menu ---");
            System.out.println("1. Add Matrix");
            System.out.println("2. Multiply Matrix");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            ch = sc.nextInt();

            switch (ch) {
                case 1:
					mo.readMatrix();
					mo.matadd();
				break;

                case 2:
                	mo.readMatrix();
                	mo.matMult();
                    break;
                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
            }
        }
    }
}