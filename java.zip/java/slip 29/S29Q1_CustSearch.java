/*S29Q1
	Q1) Write a program to create a class Customer
	(cno,cname,ccontNo,caddr).Write a method to search the
	customer name with given contact number and display thedetails.[10 marks]
*/

import java.util.Scanner;

class Customer {
    int cno;
    String cname;
    String ccontNo;
    String caddr;

    Customer(int cno, String cname, String ccontNo, String caddr) {
        this.cno = cno;
        this.cname = cname;
        this.ccontNo = ccontNo;
        this.caddr = caddr;
    }

    public void display() {
        System.out.println(cno+"\t"+cname+"\t"+ccontNo+"\t"+caddr);
    }

    public static void searchByContact(Customer[] cust, String contact) {
        boolean found = false;
        System.out.println("----------------------------------");
        //for (Customer c : cust) {
		for(int i = 0;i<cust.length;i++){
            if (cust[i].ccontNo.equals(contact)) {
                System.out.println("Customer found!");
                cust[i].display();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("No customer found with contact number: " + contact);
        }
    }
}

public class S29Q1_CustSearch {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of cust: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        Customer[] cust = new Customer[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Customer " + (i + 1));
            System.out.print("Customer No: ");
            int cno = sc.nextInt();
            sc.nextLine();
            System.out.print("Customer Name: ");
            String name = sc.nextLine();
            System.out.print("Contact Number: ");
            String contact = sc.nextLine();
            System.out.print("Customer Address: ");
            String addr = sc.nextLine();

            cust[i] = new Customer(cno, name, contact, addr);
        }
        System.out.println("-----------------------------");
        System.out.println("CNo\tCName\tContNo\tAddr");
        System.out.println("-----------------------------");
		for (int i = 0; i < n; i++)
		    cust[i].display();

        System.out.print("\nEnter contact number to search: ");
        String searchContact = sc.nextLine();

        Customer.searchByContact(cust, searchContact);

        sc.close();
    }
}

