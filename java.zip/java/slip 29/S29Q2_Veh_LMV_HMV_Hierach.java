/*
Q2) Write a program to create a super class Vehicle having members Company
and price.Derive two different classes LightMotorVehicle(mileage) and
HeavyMotorVehicle(capacity_in_tons). Accept the information for "n" vehicles
and display the information inappropriate form. While taking data, ask user
about the type of vehicle first.[20 marks]
*/
import java.util.Scanner;

// Superclass
class Vehicle {
    String cName;
    double price;

    void read(Scanner sc) {
        System.out.print("Enter Company Name: ");
        cName = sc.nextLine();
        System.out.print("Enter Price: ");
        price = sc.nextDouble();
        sc.nextLine(); // consume newline
    }

    void display() {
        System.out.println("Company Name : " + cName);
        System.out.println("Price        : " + price);
    }
}

// Derived Class 1 - LMV
class LMV extends Vehicle {
    double mileage;

    void read(Scanner sc) {
        super.read(sc);
        System.out.print("Enter Mileage (km/l): ");
        mileage = sc.nextDouble();
        sc.nextLine(); // consume newline
    }

    void display() {
        super.display();
        System.out.println("Mileage      : " + mileage + " km/l");
    }
}

// Derived Class 2 - HMV
class HMV extends Vehicle {
    double cap_in_tons;

    void read(Scanner sc) {
        super.read(sc);
        System.out.print("Enter Capacity in Tons: ");
        cap_in_tons = sc.nextDouble();
        sc.nextLine(); // consume newline
    }

    void display() {
        super.display();
        System.out.println("Capacity     : " + cap_in_tons + " tons");
    }
}

public class S29Q2_Veh_LMV_HMV_Hierach {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of vehicles: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        Vehicle[] vehicles = new Vehicle[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Vehicle " + (i + 1));
            System.out.print("Enter type of vehicle (LMV/HMV): ");
            String type = sc.nextLine();

            if (type.equalsIgnoreCase("LMV")) {
                vehicles[i] = new LMV();
            } else if (type.equalsIgnoreCase("HMV")) {
                vehicles[i] = new HMV();
            } else {
                System.out.println("?? Invalid type! Defaulting to LMV.");
                vehicles[i] = new LMV();
            }

            vehicles[i].read(sc);
        }

        System.out.println("\n===== Vehicle Details =====");
        for (int i = 0; i < n; i++) {
            System.out.println("\n--- Vehicle " + (i + 1) + " ---");
            vehicles[i].display();
        }

        sc.close();
    }
}
