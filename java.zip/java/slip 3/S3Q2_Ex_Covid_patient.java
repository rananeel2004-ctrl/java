/*
	S3Q2 Q2) Define a class patient (pname, p_age,
	p_ox_lvl,p_HRCT_report). Create an object of patient.
	Handle appropriate exception while patient oxygen level less than 95%
	and HRCT scan report greater than 10, then throw user defined Exception
	�Patient is Covid Positive(+) and Need to Hospitalized� otherwise display
	its information.[20 marks]
*/

import java.util.Scanner;

class CovideEx extends Exception {
	String ExMsg="";
    CovideEx(String msg) {
        //super(msg);
        ExMsg = msg;
    }
    public String toString()
    {
		return ExMsg;
	}
}

// Patient Class
class Patient {
    String pname;
    int p_age,p_ox_lvl,p_HRCT_report;
	Scanner sc = new Scanner(System.in);
    void accept() {
		try
		{
			System.out.print("Enter Patient Name: ");
			pname = sc.nextLine();
			System.out.print("Enter Patient Age: ");
			p_age = sc.nextInt();
			System.out.print("Enter Oxygen Level (%): ");
			p_ox_lvl = sc.nextInt();
			System.out.print("Enter HRCT Report Score: ");
			p_HRCT_report = sc.nextInt();
			sc.nextLine(); // consume newline

			if (p_ox_lvl < 95 && p_HRCT_report > 10) {
				throw new CovideEx("Patient is Covid + & Need to Hospitalized");
			} else {
				display();
			}
		}catch(CovideEx e)
		{
			System.out.println("Error = "+e);
		}
    }

    void display() {
        System.out.println("\n---- Patient Details ----");
        System.out.println("Name   : " + pname);
        System.out.println("Age    : " + p_age);
        System.out.println("Oxygen : " + p_ox_lvl + "%");
        System.out.println("HRCT   : " + p_HRCT_report);
    }
}

public class S3Q2_Ex_Covid_patient {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Patient p = new Patient();
        p.accept();
    }
}