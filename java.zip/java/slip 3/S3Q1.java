/*Q1) Write a program to accept name of City Names from the user and sort them
in ascendingorder.[10 marks]*/

import java.util.*;
//import java.util.Arrays;

class City {

    int n = 0;
    String cNames[];
    Scanner sc = new Scanner(System.in);

    void readCities() {
        System.out.print("Enter the number of City Names: ");
        n = sc.nextInt();
        cNames = new String[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter name of city " + (i + 1) + ": ");
            cNames[i] = sc.next();
        }
    }

    /*void sortCities() {
        Arrays.sort(cNames);

        System.out.println("\nCities in Ascending Order:");
        for (String city : cNames) {
            System.out.println(city);
        }
    }*/
    void sortCities()
    {
		for (int i = 0; i < cNames.length - 1; i++){
			for (int j = i + 1; j < cNames.length; j++){
				if (cNames[i].compareTo(cNames[j])>0){

					String temp = cNames[i];
					cNames[i] = cNames[j];
					cNames[j] = temp;
				}
			}
		}
	}
	void printSortedData()
	{
		for (int i = 0; i < cNames.length; i++)
		System.out.println(""+cNames[i]);
	}
}
class S3Q1 {
    public static void main(String s[]) {
        City c = new City();
        c.readCities();
        c.sortCities();
        System.out.println("After Sort \n");
        c.printSortedData();
    }
}