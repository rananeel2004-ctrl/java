/*
S4Q2 Q2) Write a program to design a screen using AWT that will take a user
name and password. If the user name and password are not same, raise an
Exception with appropriate message. User can have 3 login chances only.
Use clear button to clear the TextFields..[20 marks]
create main class as S4Q2_Ex_UserPWD
*/
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

// User Defined Exception
class InvalidLoginEx extends Exception {
    //String msg="";
    InvalidLoginEx(String msg) {
        super(msg);
        //this.msg = msg;
    }
}

public class S4Q2_Ex_UserPWD extends JFrame implements ActionListener {
    Label l1, l2, lmsg;
    TextField tuser, tpass;
    Button blogin, bclear;
    int attempts = 0; // count login attempts

    public S4Q2_Ex_UserPWD()
    {
		//setTitle("Login Screen");
		setSize(400, 200);
		setVisible(true);

        setLayout(new GridLayout(4, 2, 10, 10));
        //setLayout(new FlowLayout());

        l1 = new Label("Username:");
        l2 = new Label("Password:");
        lmsg = new Label("");

        tuser = new TextField(20);
        tpass = new TextField(20);
        tpass.setEchoChar('*'); // mask password

        blogin = new Button("Login");
        bclear = new Button("Clear");

        add(l1);        add(tuser);
        add(l2);        add(tpass);
        add(blogin);    add(bclear);        add(lmsg);

        blogin.addActionListener(this);
        bclear.addActionListener(this);
    }

    public void actionPerformed(ActionEvent ae)
    {


        if (ae.getSource() == blogin)
        {
			String uname = tuser.getText();
			String pwd = tpass.getText();
            try {
                if (!uname.equals(pwd)) {
                    attempts++;
                    throw new InvalidLoginEx("Invalid Login! Attempts left: " +
                    (3 - attempts));
                } else {
                    lmsg.setText("Login Successful!");
                    blogin.setEnabled(false);
                }
            }
            catch (InvalidLoginEx e)
            {
                lmsg.setText(e.getMessage());
                if (attempts >= 3) {
                    lmsg.setText("3 Attempts Over! Login Disabled.");
                    blogin.setEnabled(false);
                }
            }
        }
        else if (ae.getSource() == bclear)
        {
            tuser.setText("");
            tpass.setText("");
            lmsg.setText("");
        }
    }

    public static void main(String[] args) {
        new S4Q2_Ex_UserPWD();
    }
}
