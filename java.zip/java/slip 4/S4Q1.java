/* Q1) Write a program to print an array after changing the rows and columns
of a given two-dimensional array.[10 marks]*/

import java.util.Scanner;

class MatTranspose {
    int i = 0, j = 0, m[][] = new int[3][3];
    Scanner sc = new Scanner(System.in);

    void readMatrix() {
        System.out.print("Enter elements for 3X3 Matrix ");
        for (i = 0; i < 3; i++) {
            for (j = 0; j < 3; j++)
                m[i][j] = sc.nextInt();
        }
    }

    void dispmat() {
		for (i = 0; i < 3; i++) {
			System.out.println("");
				for (j = 0; j < 3; j++)
					System.out.print(" "+m[i][j]);
        }
    }

    void dispMatTrans() {
		for (i = 0; i < 3; i++) {
			System.out.println("");
			for (j = 0; j < 3; j++)
				System.out.print(" "+m[j][i]);
		}
    }
}
public class S4Q1 {
    public static void main(String[] args) {
	MatTranspose mt = new MatTranspose();
	mt.readMatrix();
	System.out.print("\nOriginal Matrix \n");
	mt.dispmat();
	System.out.print("\nAfter Transpose Matrix \n");
	mt.dispMatTrans();
    }
}
