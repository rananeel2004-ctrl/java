/*
Q1) Write a Program to print all Prime numbers in an array of �n� elements.
(use command line arguments)[10 marks]
*/

class S1Q1
{
	public static void main(String s[])
	{
		int n =0,i=0,j=0,f=0;

		for(i=0;i<s.length;i++)
		{
			n = Integer.parseInt(s[i]);
			f=0;
			for(j=2;j<n;j++)
			{
				if(n%j==0)
				{
					f=1;
					break;
				}
			}
			if(f==0)
			System.out.println(" "+n);
		}
	}
}