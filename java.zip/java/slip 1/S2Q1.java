import java.util.Scanner;

public class S2Q1 {

    // BMI = Wts. In kgs / (ht)2)
    public static void main(String s[]) {
        double BMI = 0.0, ht = 0.0, wt = 0.0;
        String fname = "", lname = "";
        Scanner sc = new Scanner(System.in);

        try {
            System.out.println("Enter FName, Laname, Ht & Wt");
            fname = sc.nextLine();
            lname = sc.nextLine();
            ht = sc.nextDouble();
            wt = sc.nextDouble();

            BMI = wt / (ht * ht);

            System.out.println(
                    "Name = " + fname + " " + lname + "\nHeight = " + ht + "\nWeight = " + wt + "\nBMI = " + BMI);

        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("Error = " + e);
        }
    }

}
