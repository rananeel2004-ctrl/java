/*S1Q2
Q2) write java program to Define an abstract class Staff with protected
members id and name. Define a parameterized constructor. Define one subclass
OfficeStaff with member dName. Create n objects of OfficeStaff and display
all details.
*/

import java.util.Scanner;

abstract class Staff {
    protected int memId;
    protected String memName;

    Staff(int memId, String memName) {
        this.memId = memId;
        this.memName = memName;
    }

    abstract void display();
}

class OfficeStaff extends Staff {
    String dName;

    OfficeStaff(int memId, String memName, String dName) {
        super(memId, memName);
        this.dName = dName;
    }

    void display() {
        System.out.println("ID: " + memId + "\nName: " + memName + "\nDepartment: " + dName);
    }
}

public class S1Q2_Ab_Staff {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of Office Staff: ");
        int n = sc.nextInt();
        sc.nextLine();

        OfficeStaff sa[] = new OfficeStaff[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Staff " + (i + 1));
            System.out.print("Enter Member ID: ");
            int id = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Member Name: ");
            String name = sc.nextLine();
            System.out.print("Enter Department: ");
            String dept = sc.nextLine();

            sa[i] = new OfficeStaff(id, name, dept);
        }

        System.out.println("\n===== Office Staff Details =====");

        for (int i=0;i<sa.length;i++)
        {
            sa[i].display();
        }

        sc.close();
    }
}