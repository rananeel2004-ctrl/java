/*
Q1) Write a program to find the Square of given number using function
interface.[10 marks]
*/
// Functional Interface
@FunctionalInterface
interface Square {
    int findSquare(int n);
}

public class S16Q1_FunInterf_FindSquare {
    public static void main(String[] args) {
        // Lambda expression for square
        Square s = (n) -> n * n;

        int num = 7;
        System.out.println("Square of " + num + " = " + s.findSquare(num));
    }
}
