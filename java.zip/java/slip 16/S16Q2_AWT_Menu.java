import java.awt.*;
import java.awt.event.*;

public class S16Q2_AWT_Menu extends Frame implements ActionListener {

    MenuBar mb;
    Menu fMenu, eMenu, aMenu;
    MenuItem mNew, mOpen, mSave, mShowAbout, mExit;

    public S16Q2_AWT_Menu() {

        // Frame Settings
		setTitle("AWT Menu Example");
		setSize(400, 300);
        setVisible(true);

        // Create MenuBar
        mb = new MenuBar();

        // --- File Menu ---
        fMenu = new Menu("File");
        // --- Edit Menu ---
		eMenu = new Menu("Edit");
		// --- About Menu ---
		aMenu = new Menu("About");


        mNew = new MenuItem("New");
        mOpen = new MenuItem("Open");
        mSave = new MenuItem("Save");
        mShowAbout = new MenuItem("Show About");
        mExit = new MenuItem("Exit");

        fMenu.add(mNew);
        fMenu.add(mOpen);
        fMenu.add(mSave);
        fMenu.addSeparator();       // Separator after Save
        fMenu.add(mShowAbout);
        fMenu.addSeparator();       // Separator after Show About
        fMenu.add(mExit);


        // Add menus to MenuBar
        mb.add(fMenu);
        mb.add(eMenu);
        mb.add(aMenu);

        // Set MenuBar
        setMenuBar(mb);

        // Add ActionListeners
        mNew.addActionListener(this);
        mOpen.addActionListener(this);
        mSave.addActionListener(this);
        mShowAbout.addActionListener(this);
        mExit.addActionListener(this);

        // Window Close
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent we) {
                System.exit(0);
            }
        });
    }
    public void actionPerformed(ActionEvent ae) {
        String cmd = ae.getActionCommand();
        if (cmd.equals("Exit")) {
            System.exit(0);
        } else {
            System.out.println("Selected: " + cmd);
        }
    }

    public static void main(String[] args) {
        new S16Q2_AWT_Menu();
    }
}