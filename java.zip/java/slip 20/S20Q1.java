/*
S20Q1 Q1) Write a Program to illustrate multilevel Inheritance such that
country is inherited from continent. State is inherited from country.
Display the place, state, country and continent.[10 marks]
*/
import java.io.*;
class continent
{
	String continentName="";
	continent(String contiName)
	{
		continentName = contiName;
	}
	void dispInfo()
	{
		System.out.println("Continent Name - "+continentName);
	}
}
class country extends continent
{
	String countryName="";
	country(String continentName,String countName)
	{
		super(continentName);
		countryName = countName;
	}
	void dispInfo()
	{
		super.dispInfo();
		System.out.println("Country - "+countryName);
	}
}
class state extends country
{
	String stName="";
	state(String continentName, String countName,String stName)
	{
		super(continentName,countName);
		this.stName = stName;
	}
	void dispInfo()
	{
		super.dispInfo();
		System.out.println("State - "+stName);
	}
}
class place extends state
{
	String pName="";
	place(String continentName,String countName,String stName,String pn)
	{
		super(continentName,countName,stName);
		pName=pn;
	}
	void dispInfo()
	{
		super.dispInfo();
		System.out.println("Place - "+pName);

	}
}
class S20Q1
{
	public static void main(String s[])
	{
		String pName="",stName="",countryName="",continentName="";
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try
		{
			System.out.println("Enter the Name of Continent,Country,state & place ");
			continentName=br.readLine();
			countryName=br.readLine();
			stName=br.readLine();
			pName=br.readLine();
			place p = new place(continentName,countryName,stName,pName);
			p.dispInfo();
		}catch(Exception e)
		{
			System.out.println("Error - "+e);
		}
	}
}