/* S20Q2
Q2) Write a package for Operation, which has two classes, Addition
and Maximum. Addition hastwo methods add () and subtract (), which are used
to add two integers and subtract two,float values respectively. Maximum has a
method max () to display the maximum of two integers[20 marks]
*/

import Operation.Addition;
import Operation.Maximum;

public class S20Q2_OperationPack {
    public static void main(String[] args) {
        Addition addObj = new Addition();
        Maximum maxObj = new Maximum();

        int sum = addObj.add(20, 30);
        System.out.println("Addition of 20 and 30 = " + sum);

        float diff = addObj.subtract(50.5f, 20.3f);
        System.out.println("Subtraction of 50.5 and 20.3 = " + diff);

        int maximum = maxObj.max(40, 25);
        System.out.println("Maximum of 40 and 25 = " + maximum);
    }
}
