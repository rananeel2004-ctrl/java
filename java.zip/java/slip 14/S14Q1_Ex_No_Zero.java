/*
S14Q1 Q1) Write a program to accept a number from the user, if number is zero
then throw user defined exception �Number is 0� otherwise check whether no is
prime or not (Use static keyword).[10 marks]
*/

import java.util.Scanner;

class NoZeroEx extends Exception {
    NoZeroEx(String msg) {
        super(msg);
    }
}

public class S14Q1_Ex_No_Zero {

    static void checkPrime(int n) {
        if (n <= 1) {
            System.out.println(n + " is NOT Prime");
            return;
        }
        for (int i = 2; i <= n / 2; i++) {
            if (n % i == 0) {
                System.out.println(n + " is NOT Prime");
                return;
            }
        }
        System.out.println(n + " is Prime");
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a Number: ");
        int num = sc.nextInt();

        try {
            if (num == 0) {
                throw new NoZeroEx("Number is 0");
            } else {
                checkPrime(num);
            }
        } catch (NoZeroEx e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
