/* S14Q2
	Q2) Write a Java program to create a Package �SY� which has a class
	SYMarks (members �ComputerTotal, MathsTotal, and ElectronicsTotal).
	Create another package TY which has a class
	TYMarks (members � Theory, Practicals).
	Create �n� objects of Student class (having rollNumber, name, SYMarks
	and TYMarks).
	Add the marks of SY and TY computer subjects and calculate the
	Grade (�A� for >= 70, �B� for >= 60 �C� for >= 50,
	Pass Class for > =40 else �FAIL�)
	and display the result of the student in proper format.[20 marks]
*/
import java.util.Scanner;
import SY.SYMarks;
import TY.TYMarks;

class Student {
    int rno;
    String sname;
    SYMarks sym;
    TYMarks tym;
    double per;

    Student(int rno, String sname, SYMarks sym, TYMarks tym) {
        this.rno = rno;
        this.sname = sname;
        this.sym = sym;
        this.tym = tym;
    }

    // Calculate computer total = SY CompTotal + TY Theory + TY Practical
    int getComputerTotal() {
        return sym.CompTotal + tym.TheoryTot + tym.PractTot;
    }

    // Calculate grade
    String getGrade() {
        per = getComputerTotal() / 3.0;  // Avg out of 100 per subject
        System.out.println("Per = "+per);
        if (per >= 70) return "A";
        else if (per >= 60) return "B";
        else if (per >= 50) return "C";
        else if (per >= 40) return "Pass Class";
        else return "FAIL";
    }

    void display() {
        System.out.println("------------------------------------------------");
        System.out.println(rno+"\t"+sname+"\t"+sym.CompTotal+
        "\t"+tym.TheoryTot+"\t"+tym.PractTot+"\t"+getComputerTotal()+"\t"+per+
        "\t"+getGrade());
    }
}

public class S14Q2_SYTYPack {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of students: ");
        int n = sc.nextInt();
        sc.nextLine();

        Student students[] = new Student[n];

        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Student " + (i + 1));
            System.out.print("Enter Roll No: ");
            int rno = sc.nextInt();
            sc.nextLine();
            System.out.print("Enter Student Name: ");
            String name = sc.nextLine();

            System.out.print("Enter SY Computer Marks: ");
            int comp = sc.nextInt();
            System.out.print("Enter SY Maths Marks: ");
            int maths = sc.nextInt();
            System.out.print("Enter SY Electronics Marks: ");
            int ele = sc.nextInt();

            System.out.print("Enter TY Theory Marks: ");
            int theory = sc.nextInt();
            System.out.print("Enter TY Practical Marks: ");
            int pract = sc.nextInt();

            SYMarks sym = new SYMarks(comp, maths, ele);
            TYMarks tym = new TYMarks(theory, pract);

            students[i] = new Student(rno, name, sym, tym);
        }

        System.out.println("\n========= Student Results =========");
        System.out.println("rNo\tsName\tcTotal\ttTot\tpTot"+
		"\tCTotal\tPer\tGrade");
		for (int i=0;i<students.length;i++) {
            students[i].display();
        }

        //sc.close();
    }
}
