#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX 100

// Function to implement typeline command
void typeline(char *option, char *filename) {
    FILE *fp;
    char line[256];
    int n, count = 0;

    fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: Cannot open file %s\n", filename);
        return;
    }

    if (option[0] == '+') {
        n = atoi(option + 1);
        while (fgets(line, sizeof(line), fp) != NULL && count < n) {
            printf("%s", line);
            count++;
        }
    } else if (strcmp(option, "-a") == 0) {
        while (fgets(line, sizeof(line), fp) != NULL) {
            printf("%s", line);
        }
    } else {
        printf("Invalid option for typeline. Use +n or -a\n");
    }

    fclose(fp);
}

int main() {
    char input[MAX], *args[10];
    int i;
    pid_t pid;

    while (1) {
        printf("myshell$ ");       // Display custom prompt
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL)
            break;

        input[strcspn(input, "\n")] = '\0'; // remove newline

        if (strlen(input) == 0)
            continue;

        // Exit command
        if (strcmp(input, "exit") == 0)
            break;

        // Tokenize input
        i = 0;
        args[i] = strtok(input, " ");
        while (args[i] != NULL)
            args[++i] = strtok(NULL, " ");

        // Implement typeline command
        if (args[0] && strcmp(args[0], "typeline") == 0) {
            if (args[1] && args[2])
                typeline(args[1], args[2]);
            else
                printf("Usage: typeline [+n | -a] filename\n");
            continue;
        }

        // Create child process for other commands
        pid = fork();
        if (pid < 0) {
            printf("Error: Fork failed\n");
        } else if (pid == 0) {
            // Child executes the command
            if (execvp(args[0], args) == -1)
                printf("Command not found: %s\n", args[0]);
            exit(0);
        } else {
            wait(NULL); // Parent waits for child to finish
        }
    }

    return 0;
}
