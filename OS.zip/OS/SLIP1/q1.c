#include <stdio.h>

#define MAX 20

// Function to find LFU page index
int findLFU(int frequency[], int n_frames) {
    int min = frequency[0];
    int pos = 0;
    for (int i = 1; i < n_frames; i++) {
        if (frequency[i] < min)
            min = frequency[i], pos = i;
    }
    return pos;
}

int main() {
    int n_frames, i, j, k, ref_len;
    int frames[MAX], freq[MAX];
    int ref_string[MAX] = {3,4,5,4,3,4,7,2,4,5,6,7,2,4,6};
    ref_len = 15;
    int page_faults = 0, found, replace_index;

    printf("Enter number of frames: ");
    scanf("%d", &n_frames);

    // Initialize
    for (i = 0; i < n_frames; i++) {
        frames[i] = -1;
        freq[i] = 0;
    }

    printf("\nReference String:\n");
    for (i = 0; i < ref_len; i++)
        printf("%d ", ref_string[i]);
    printf("\n\nPage Replacement Process (LFU):\n");

    // Process each page
    for (i = 0; i < ref_len; i++) {
        found = 0;

        // Check if page already in frame
        for (j = 0; j < n_frames; j++) {
            if (frames[j] == ref_string[i]) {
                freq[j]++; // Increase frequency
                found = 1;
                break;
            }
        }

        // Page Fault
        if (!found) {
            // Check for empty frame
            int empty = -1;
            for (j = 0; j < n_frames; j++) {
                if (frames[j] == -1) {
                    empty = j;
                    break;
                }
            }

            if (empty != -1) {
                frames[empty] = ref_string[i];
                freq[empty] = 1;
            } else {
                replace_index = findLFU(freq, n_frames);
                frames[replace_index] = ref_string[i];
                freq[replace_index] = 1;
            }
            page_faults++;
        }

        // Print frame status
        printf("After page %2d: ", ref_string[i]);
        for (k = 0; k < n_frames; k++) {
            if (frames[k] != -1)
                printf("%2d ", frames[k]);
            else
                printf("-- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);
    return 0;
}
