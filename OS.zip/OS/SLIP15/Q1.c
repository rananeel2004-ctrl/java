#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>

#define MAX_LINE 80
#define MAX_ARGS 10

// Function to handle the custom 'list' command
void handle_list_command(char** args) {
    if (args[1] == NULL || args[2] == NULL || strcmp(args[1], "f") != 0) {
        fprintf(stderr, "myshell$: Usage: list f <dirname>\n");
        return;
    }

    DIR *dir;
    struct dirent *entry;
    
    // Open the directory specified by the third argument
    dir = opendir(args[2]);
    if (dir == NULL) {
        perror("myshell$: opendir failed");
        return;
    }

    // 'list f': print file names
    while ((entry = readdir(dir)) != NULL) {
        printf("%s\n", entry->d_name);
    }

    closedir(dir);
}

int main(void) {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    pid_t pid;
    int status;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(line, MAX_LINE, stdin) == NULL) {
            break; 
        }
        
        // Remove the trailing newline character
        line[strcspn(line, "\n")] = 0;

        // Tokenize the input line
        char *token = strtok(line, " ");
        int i = 0;
        while (token != NULL) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL; // NULL-terminate the argument list

        if (args[0] == NULL) {
            continue; // Handle empty commands
        }

        // Check for built-in 'exit' command
        if (strcmp(args[0], "exit") == 0) {
            exit(0);
        }
        
        // Check for the custom 'list' command
        if (strcmp(args[0], "list") == 0) {
            handle_list_command(args);
            continue;
        }

        // Create a child process
        pid = fork();
        if (pid < 0) {
            perror("myshell$: fork failed");
        } else if (pid == 0) {
            // Child process: execute the command
            execvp(args[0], args);
            // This line only runs if execvp fails
            perror("myshell$: Command not found");
            exit(1);
        } else {
            // Parent process: wait for the child to finish
            waitpid(pid, &status, 0);
        }
    }

    return 0;
}