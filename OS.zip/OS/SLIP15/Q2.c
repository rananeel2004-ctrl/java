#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Process {
    int id;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

int main() {
    int num_processes;
    cout << "Enter number of processes: ";
    cin >> num_processes;

    vector<Process> processes(num_processes);
    cout << "Enter arrival time and burst time for each process:" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].id = i + 1;
        cout << "Process " << processes[i].id << " Arrival Time: ";
        cin >> processes[i].arrival_time;
        cout << "Process " << processes[i].id << " Burst Time: ";
        cin >> processes[i].burst_time;
        processes[i].remaining_time = processes[i].burst_time;
    }

    int current_time = 0;
    int completed_processes = 0;
    int min_remaining_time = 99999;
    int shortest_job_index = -1;
    
    cout << "\n---------------------Gantt Chart---------------------" << endl;

    while (completed_processes < num_processes) {
        min_remaining_time = 99999;
        shortest_job_index = -1;

        // Find the process with the shortest remaining time
        for (int i = 0; i < num_processes; ++i) {
            if (processes[i].arrival_time <= current_time && processes[i].remaining_time > 0) {
                if (processes[i].remaining_time < min_remaining_time) {
                    min_remaining_time = processes[i].remaining_time;
                    shortest_job_index = i;
                }
            }
        }

        if (shortest_job_index == -1) {
            // No process is ready, increment time
            current_time++;
            continue;
        }

        // Execute the shortest job for one time unit
        processes[shortest_job_index].remaining_time--;
        current_time++;

        // Print to the Gantt chart (simplified)
        cout << " | P" << processes[shortest_job_index].id << " |";

        // Check if the process has completed
        if (processes[shortest_job_index].remaining_time == 0) {
            processes[shortest_job_index].completion_time = current_time;
            completed_processes++;
        }
    }

    cout << "\n-----------------------------------------------------" << endl;

    double total_turnaround_time = 0;
    double total_waiting_time = 0;

    cout << "\nResults:" << endl;
    cout << "Process\tArrival\tBurst\tCompletion\tTurnaround\tWaiting" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].turnaround_time = processes[i].completion_time - processes[i].arrival_time;
        processes[i].waiting_time = processes[i].turnaround_time - processes[i].burst_time;

        total_turnaround_time += processes[i].turnaround_time;
        total_waiting_time += processes[i].waiting_time;

        cout << processes[i].id << "\t" << processes[i].arrival_time << "\t" << processes[i].burst_time << "\t"
             << processes[i].completion_time << "\t\t" << processes[i].turnaround_time << "\t\t"
             << processes[i].waiting_time << endl;
    }

    cout << fixed << setprecision(2);
    cout << "\nAverage Turnaround Time: " << total_turnaround_time / num_processes << endl;
    cout << "Average Waiting Time: " << total_waiting_time / num_processes << endl;

    return 0;
}