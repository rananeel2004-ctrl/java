#include <iostream>
#include <vector>
#include <list>
#include <algorithm>

using namespace std;

int main() {
    int n; // Number of memory frames
    cout << "Enter the number of frames (n): ";
    cin >> n;

    vector<int> reference_string = {3, 4, 5, 6, 3, 4, 7, 3, 4, 5, 6, 7, 2, 4, 6};
    list<int> frames;
    int page_faults = 0;
    
    cout << "Reference String: ";
    for (int page : reference_string) {
        cout << page << " ";
    }
    cout << endl << endl;

    for (int page : reference_string) {
        // Find the page in the frames list
        auto it = find(frames.begin(), frames.end(), page);

        if (it != frames.end()) {
            // Page hit
            cout << "Page " << page << " is a hit. Frames: ";
            frames.erase(it); // Remove the page from its current position
            frames.push_front(page); // Move it to the front (most recently used)
        } else {
            // Page fault
            cout << "Page " << page << " is a fault. Frames: ";
            page_faults++;

            if (frames.size() == n) {
                // Memory is full, remove the least recently used page (from the back)
                frames.pop_back();
            }
            frames.push_front(page); // Add the new page to the front
        }

        // Print current state of frames
        for (int p : frames) {
            cout << p << " ";
        }
        cout << endl;
    }

    cout << "\nTotal number of page faults: " << page_faults << endl;

    return 0;
}