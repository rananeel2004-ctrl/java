#include <stdio.h>

// Structure to hold process information
struct Process {
    int pid;
    int arrival_time;
    int burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

void sort_by_arrival(struct Process proc[], int n) {
    // A simple bubble sort to order processes by arrival time
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (proc[j].arrival_time > proc[j+1].arrival_time) {
                struct Process temp = proc[j];
                proc[j] = proc[j+1];
                proc[j+1] = temp;
            }
        }
    }
}

int main() {
    int n, i;
    float total_waiting_time = 0;
    float total_turnaround_time = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct Process proc[n];

    printf("Enter arrival time and burst time for each process:\n");
    for (i = 0; i < n; i++) {
        proc[i].pid = i + 1;
        printf("Process %d - Arrival Time: ", proc[i].pid);
        scanf("%d", &proc[i].arrival_time);
        printf("Process %d - Burst Time: ", proc[i].pid);
        scanf("%d", &proc[i].burst_time);
    }
    
    // Sort processes by arrival time to ensure FCFS order
    sort_by_arrival(proc, n);

    // Calculate completion, turnaround, and waiting times
    int current_time = 0;
    printf("\n\nFCFS Scheduling Simulation\n");

    // Print Gantt Chart header
    printf("\n-------------------Gantt Chart-------------------\n");
    printf("| ");
    
    // Calculate and print for the first process
    if (proc[0].arrival_time > 0) {
        printf("IDLE (%d-%d) | ", 0, proc[0].arrival_time);
        current_time = proc[0].arrival_time;
    }

    // First process
    proc[0].completion_time = current_time + proc[0].burst_time;
    proc[0].turnaround_time = proc[0].completion_time - proc[0].arrival_time;
    proc[0].waiting_time = proc[0].turnaround_time - proc[0].burst_time;
    current_time = proc[0].completion_time;
    
    // Print Gantt Chart entry for the first process
    printf("P%d (%d-%d) | ", proc[0].pid, proc[0].arrival_time, proc[0].completion_time);

    total_waiting_time += proc[0].waiting_time;
    total_turnaround_time += proc[0].turnaround_time;

    // Subsequent processes
    for (i = 1; i < n; i++) {
        // If CPU is idle before a process arrives
        if (proc[i].arrival_time > current_time) {
            printf("IDLE (%d-%d) | ", current_time, proc[i].arrival_time);
            current_time = proc[i].arrival_time;
        }

        proc[i].completion_time = current_time + proc[i].burst_time;
        proc[i].turnaround_time = proc[i].completion_time - proc[i].arrival_time;
        proc[i].waiting_time = proc[i].turnaround_time - proc[i].burst_time;
        current_time = proc[i].completion_time;
        
        // Print Gantt Chart entry
        printf("P%d (%d-%d) | ", proc[i].pid, proc[i].arrival_time, proc[i].completion_time);

        total_waiting_time += proc[i].waiting_time;
        total_turnaround_time += proc[i].turnaround_time;
    }
    printf("\n------------------------------------------------\n");

    // Print the results table
    printf("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\n");
    for (i = 0; i < n; i++) {
        printf("P%d\t%d\t\t%d\t\t%d\t\t%d\n", proc[i].pid, proc[i].arrival_time,
               proc[i].burst_time, proc[i].waiting_time, proc[i].turnaround_time);
    }
    
    // Print average times
    printf("\nAverage Waiting Time: %.2f\n", total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n", total_turnaround_time / n);

    return 0;
}