#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAX 100

// Function to implement 'count' command
void count_command(char *option, char *filename) {
    FILE *fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: Cannot open file %s\n", filename);
        return;
    }

    char ch;
    int char_count = 0, word_count = 0, line_count = 0;
    int in_word = 0;

    while ((ch = fgetc(fp)) != EOF) {
        char_count++;

        if (ch == '\n')
            line_count++;

        if (isspace(ch))
            in_word = 0;
        else if (in_word == 0) {
            in_word = 1;
            word_count++;
        }
    }

    fclose(fp);

    if (strcmp(option, "c") == 0)
        printf("Number of characters in %s = %d\n", filename, char_count);
    else if (strcmp(option, "w") == 0)
        printf("Number of words in %s = %d\n", filename, word_count);
    else if (strcmp(option, "l") == 0)
        printf("Number of lines in %s = %d\n", filename, line_count);
    else
        printf("Invalid option for count. Use c, w, or l\n");
}

int main() {
    char input[MAX], *args[10];
    int i;
    pid_t pid;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL)
            break;

        input[strcspn(input, "\n")] = '\0'; // remove newline

        if (strlen(input) == 0)
            continue;

        // Exit command
        if (strcmp(input, "exit") == 0)
            break;

        // Tokenize input
        i = 0;
        args[i] = strtok(input, " ");
        while (args[i] != NULL)
            args[++i] = strtok(NULL, " ");

        // Handle 'count' command
        if (args[0] && strcmp(args[0], "count") == 0) {
            if (args[1] && args[2])
                count_command(args[1], args[2]);
            else
                printf("Usage: count [c|w|l] filename\n");
            continue;
        }

        // Fork to execute other commands
        pid = fork();
        if (pid < 0) {
            printf("Error: Fork failed\n");
        } else if (pid == 0) {
            if (execvp(args[0], args) == -1)
                printf("Command not found: %s\n", args[0]);
            exit(0);
        } else {
            wait(NULL);  // Parent waits
        }
    }

    return 0;
}
