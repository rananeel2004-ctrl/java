#include <stdio.h>
#define MAX 20

int main() {
    int n_frames, i, j;
    int frames[MAX], freq[MAX];
    int ref_string[MAX] = {3,4,5,6,3,4,7,3,4,5,6,7,2,4,6};
    int ref_len = 15;
    int page_faults = 0;

    printf("Enter number of frames: ");
    scanf("%d", &n_frames);

    // Initialize frames and frequency counters
    for (i = 0; i < n_frames; i++) {
        frames[i] = -1;
        freq[i] = 0;
    }

    printf("\nReference String:\n");
    for (i = 0; i < ref_len; i++)
        printf("%d ", ref_string[i]);
    printf("\n\nPage Replacement Process (LFU):\n");

    for (i = 0; i < ref_len; i++) {
        int current_page = ref_string[i];
        int found = 0;

        // Check if page is already in frame
        for (j = 0; j < n_frames; j++) {
            if (frames[j] == current_page) {
                freq[j]++;  // Increment frequency
                found = 1;
                break;
            }
        }

        // Page fault occurs
        if (!found) {
            int replace_index = -1;
            int min_freq = 1e9;

            // Find empty frame
            for (j = 0; j < n_frames; j++) {
                if (frames[j] == -1) {
                    replace_index = j;
                    break;
                }
            }

            // If no empty frame, find LFU page
            if (replace_index == -1) {
                for (j = 0; j < n_frames; j++) {
                    if (freq[j] < min_freq) {
                        min_freq = freq[j];
                        replace_index = j;
                    }
                }
            }

            // Replace page
            frames[replace_index] = current_page;
            freq[replace_index] = 1;  // Reset frequency
            page_faults++;
        }

        // Print frame status
        printf("After page %2d: ", current_page);
        for (j = 0; j < n_frames; j++) {
            if (frames[j] != -1)
                printf("%2d(f=%d) ", frames[j], freq[j]);
            else
                printf("-- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
