#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_LINE 1024
#define MAX_ARGS 64

// Function to implement the 'typeline' command
void typeline_file(const char *filename) {
    FILE *file;
    char buffer[MAX_LINE];

    // Open the file for reading
    file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    // Read and print the file content line by line
    while (fgets(buffer, MAX_LINE, file) != NULL) {
        printf("%s", buffer);
    }

    // Close the file
    fclose(file);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    pid_t pid;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(line, MAX_LINE, stdin) == NULL) {
            break; // Handle Ctrl+D
        }

        // Tokenize the input string
        int i = 0;
        args[i] = strtok(line, " \n");
        while (args[i] != NULL) {
            i++;
            args[i] = strtok(NULL, " \n");
        }

        if (args[0] == NULL) {
            continue;
        }

        // Handle internal 'exit' command
        if (strcmp(args[0], "exit") == 0 || strcmp(args[0], "quit") == 0) {
            break;
        }

        // Handle custom 'typeline' command
        if (strcmp(args[0], "typeline") == 0) {
            if (i == 3 && strcmp(args[1], "-a") == 0) {
                typeline_file(args[2]);
            } else {
                printf("Usage: typeline -a <filename>\n");
            }
            continue; // Continue to the next prompt
        }

        // Execute external commands using fork() and execvp()
        pid = fork();
        if (pid < 0) {
            perror("fork failed");
            exit(1);
        } else if (pid == 0) {
            // Child process
            execvp(args[0], args);
            perror("execvp failed"); // execvp returns only on error
            exit(1);
        } else {
            // Parent process
            wait(NULL);
        }
    }

    return 0;
}