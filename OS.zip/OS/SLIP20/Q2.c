#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Structure to hold process information
struct Process {
    int pid;
    int arrival_time;
    int burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
    int is_completed;
};

void sort_by_arrival(struct Process proc[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (proc[j].arrival_time > proc[j+1].arrival_time) {
                struct Process temp = proc[j];
                proc[j] = proc[j+1];
                proc[j+1] = temp;
            }
        }
    }
}

int main() {
    int n;
    float total_wt = 0, total_tat = 0;
    int current_time = 0;
    int completed_count = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct Process proc[n];

    printf("Enter arrival time and burst time for each process:\n");
    for (int i = 0; i < n; i++) {
        proc[i].pid = i + 1;
        printf("Process %d - Arrival Time: ", proc[i].pid);
        scanf("%d", &proc[i].arrival_time);
        printf("Process %d - Burst Time: ", proc[i].pid);
        scanf("%d", &proc[i].burst_time);
        proc[i].is_completed = 0; // Initialize as not completed
    }
    
    // Initial sort by arrival time
    sort_by_arrival(proc, n);

    printf("\n\nNon-preemptive SJF Scheduling Simulation\n");
    printf("\n-------------------Gantt Chart-------------------\n");
    printf("| ");

    // Main scheduling loop
    while (completed_count < n) {
        int shortest_job_index = -1;
        int min_burst_time = INT_MAX;

        // Find the shortest job among arrived processes
        for (int i = 0; i < n; i++) {
            if (proc[i].is_completed == 0 && proc[i].arrival_time <= current_time) {
                if (proc[i].burst_time < min_burst_time) {
                    min_burst_time = proc[i].burst_time;
                    shortest_job_index = i;
                }
            }
        }

        if (shortest_job_index == -1) {
            // CPU is idle
            int next_arrival_time = INT_MAX;
            for(int i = 0; i < n; i++) {
                if(proc[i].is_completed == 0 && proc[i].arrival_time < next_arrival_time) {
                    next_arrival_time = proc[i].arrival_time;
                }
            }
            if(next_arrival_time != INT_MAX) {
                printf("IDLE (%d-%d) | ", current_time, next_arrival_time);
                current_time = next_arrival_time;
            } else {
                break; // No more processes
            }
            continue;
        }

        // Execute the selected process
        int index = shortest_job_index;
        
        // Calculate times
        proc[index].completion_time = current_time + proc[index].burst_time;
        proc[index].turnaround_time = proc[index].completion_time - proc[index].arrival_time;
        proc[index].waiting_time = proc[index].turnaround_time - proc[index].burst_time;
        
        // Update current time and mark as completed
        current_time = proc[index].completion_time;
        proc[index].is_completed = 1;
        completed_count++;
        
        // Add to total times
        total_wt += proc[index].waiting_time;
        total_tat += proc[index].turnaround_time;
        
        // Print Gantt chart entry
        printf("P%d (%d-%d) | ", proc[index].pid, proc[index].completion_time - proc[index].burst_time, proc[index].completion_time);
    }

    printf("\n------------------------------------------------\n");

    // Print the results table
    printf("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t\t%d\t\t%d\t\t%d\n", proc[i].pid, proc[i].arrival_time,
               proc[i].burst_time, proc[i].waiting_time, proc[i].turnaround_time);
    }
    
    // Print average times
    printf("\nAverage Waiting Time: %.2f\n", total_wt / n);
    printf("Average Turnaround Time: %.2f\n", total_tat / n);

    return 0;
}