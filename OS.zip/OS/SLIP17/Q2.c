#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Process {
    int id;
    int arrival_time;
    int burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

// Function to sort processes by arrival time
bool compareArrival(const Process& a, const Process& b) {
    return a.arrival_time < b.arrival_time;
}

int main() {
    int num_processes;
    cout << "Enter number of processes: ";
    cin >> num_processes;

    vector<Process> processes(num_processes);
    cout << "Enter arrival time and burst time for each process:" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].id = i + 1;
        cout << "Process " << processes[i].id << " Arrival Time: ";
        cin >> processes[i].arrival_time;
        cout << "Process " << processes[i].id << " Burst Time: ";
        cin >> processes[i].burst_time;
    }

    // Sort processes based on arrival time
    sort(processes.begin(), processes.end(), compareArrival);

    int current_time = 0;
    double total_turnaround_time = 0;
    double total_waiting_time = 0;

    cout << "\n---------------------Gantt Chart---------------------" << endl;
    cout << current_time;

    for (int i = 0; i < num_processes; ++i) {
        // If CPU is idle, advance time to the next process's arrival
        if (current_time < processes[i].arrival_time) {
            current_time = processes[i].arrival_time;
        }

        // Calculate completion time
        processes[i].completion_time = current_time + processes[i].burst_time;
        
        // Update current time
        current_time = processes[i].completion_time;
        
        // Print to Gantt chart
        cout << " | P" << processes[i].id << " | " << current_time;
    }
    
    cout << "\n-----------------------------------------------------" << endl;

    cout << "\nResults:" << endl;
    cout << "Process\tArrival\tBurst\tCompletion\tTurnaround\tWaiting" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].turnaround_time = processes[i].completion_time - processes[i].arrival_time;
        processes[i].waiting_time = processes[i].turnaround_time - processes[i].burst_time;

        total_turnaround_time += processes[i].turnaround_time;
        total_waiting_time += processes[i].waiting_time;

        cout << processes[i].id << "\t" << processes[i].arrival_time << "\t" << processes[i].burst_time << "\t"
             << processes[i].completion_time << "\t\t" << processes[i].turnaround_time << "\t\t"
             << processes[i].waiting_time << endl;
    }

    cout << fixed << setprecision(2);
    cout << "\nAverage Turnaround Time: " << total_turnaround_time / num_processes << endl;
    cout << "Average Waiting Time: " << total_waiting_time / num_processes << endl;

    return 0;
}