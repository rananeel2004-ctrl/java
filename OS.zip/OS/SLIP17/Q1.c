#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// Function to find the index of the page to be replaced using Optimal algorithm
int findOptimalReplacementIndex(const vector<int>& memory, const vector<int>& reference_string, int current_index) {
    int farthest_distance = -1;
    int page_to_replace = -1;
    
    for (int i = 0; i < memory.size(); ++i) {
        int page = memory[i];
        int next_occurrence = -1;
        
        // Find the next occurrence of this page in the future
        for (int j = current_index + 1; j < reference_string.size(); ++j) {
            if (reference_string[j] == page) {
                next_occurrence = j;
                break;
            }
        }
        
        // If the page will not be used again, it's the best one to replace
        if (next_occurrence == -1) {
            return i;
        }
        
        // Find the page with the farthest future occurrence
        if (next_occurrence > farthest_distance) {
            farthest_distance = next_occurrence;
            page_to_replace = i;
        }
    }
    return page_to_replace;
}

int main() {
    int n;
    cout << "Enter the number of frames (n): ";
    cin >> n;

    vector<int> reference_string = {7, 5, 4, 6, 8, 7, 2, 3, 1, 3, 5, 3, 4, 6};
    vector<int> memory;
    int page_faults = 0;

    cout << "Page Replacement Simulation (Optimal)" << endl;
    cout << "-----------------------------------" << endl;

    for (int i = 0; i < reference_string.size(); ++i) {
        int page = reference_string[i];
        
        // Check for page hit
        bool found = false;
        for (int m_page : memory) {
            if (m_page == page) {
                found = true;
                break;
            }
        }

        if (found) {
            // Page hit
            cout << "Accessing page: " << page << " -> Page Hit! ";
        } else {
            // Page fault
            page_faults++;
            cout << "Accessing page: " << page << " -> Page Fault! ";
            
            if (memory.size() < n) {
                // Memory not full, add the page
                memory.push_back(page);
            } else {
                // Memory is full, find and replace using Optimal
                int index_to_replace = findOptimalReplacementIndex(memory, reference_string, i);
                memory[index_to_replace] = page;
            }
        }
        
        // Display current state of memory
        cout << "Current memory frames: ";
        for (int frame : memory) {
            cout << frame << " ";
        }
        cout << endl;
    }

    cout << "\n-----------------------------------" << endl;
    cout << "Total page faults: " << page_faults << endl;

    return 0;
}