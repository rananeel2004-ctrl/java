#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>

#define MAX_LINE 1024
#define MAX_ARGS 64

// Function to handle the custom 'list f dirname' command
void list_files(char *dirname) {
    DIR *dir;
    struct dirent *entry;

    // Open the directory
    dir = opendir(dirname);
    if (dir == NULL) {
        perror("opendir");
        return;
    }

    printf("Files in directory '%s':\n", dirname);

    // Read and print file names
    while ((entry = readdir(dir)) != NULL) {
        printf("%s\n", entry->d_name);
    }

    // Close the directory
    closedir(dir);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    pid_t pid;

    while (1) {
        printf("myshell$ ");
        fflush(stdout); // Ensure the prompt is displayed immediately

        if (fgets(line, MAX_LINE, stdin) == NULL) {
            break; // Handle end of file (Ctrl+D)
        }

        // Tokenize the input string
        int i = 0;
        args[i] = strtok(line, " \n");
        while (args[i] != NULL) {
            i++;
            args[i] = strtok(NULL, " \n");
        }

        // Handle empty input
        if (args[0] == NULL) {
            continue;
        }

        // Handle internal shell commands
        if (strcmp(args[0], "exit") == 0 || strcmp(args[0], "quit") == 0) {
            break;
        }

        // Handle the custom 'list f dirname' command
        if (strcmp(args[0], "list") == 0) {
            if (i >= 3 && strcmp(args[1], "f") == 0) {
                list_files(args[2]);
            } else {
                printf("Usage: list f <directory_name>\n");
            }
            continue; // Go to the next prompt
        }

        // Create a child process to execute the command
        pid = fork();

        if (pid < 0) {
            perror("fork failed");
            exit(1);
        } else if (pid == 0) {
            // Child process: execute the command
            execvp(args[0], args);
            // execvp() only returns if an error occurs
            perror("execvp failed");
            exit(1);
        } else {
            // Parent process: wait for the child to finish
            wait(NULL);
        }
    }

    return 0;
}