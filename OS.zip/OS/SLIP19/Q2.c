#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PROCESSES 100

// Structure to hold process information
struct Process {
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

// Queue for Round Robin
int queue[MAX_PROCESSES];
int front = -1, rear = -1;

void enqueue(int pid) {
    if (rear == MAX_PROCESSES - 1) {
        printf("Queue is full\n");
    } else {
        if (front == -1) {
            front = 0;
        }
        rear++;
        queue[rear] = pid;
    }
}

int dequeue() {
    if (front == -1) {
        return -1; // Queue is empty
    } else {
        int pid = queue[front];
        if (front == rear) {
            front = rear = -1;
        } else {
            front++;
        }
        return pid;
    }
}

int is_queue_empty() {
    return front == -1;
}

void sort_by_arrival(struct Process proc[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (proc[j].arrival_time > proc[j+1].arrival_time) {
                struct Process temp = proc[j];
                proc[j] = proc[j+1];
                proc[j+1] = temp;
            }
        }
    }
}

int main() {
    int n, quantum;
    float total_wt = 0, total_tat = 0;
    int current_time = 0;
    int completed_processes = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);

    struct Process proc[n];

    printf("Enter arrival time and burst time for each process:\n");
    for (int i = 0; i < n; i++) {
        proc[i].pid = i + 1;
        printf("Process %d - Arrival Time: ", proc[i].pid);
        scanf("%d", &proc[i].arrival_time);
        printf("Process %d - Burst Time: ", proc[i].pid);
        scanf("%d", &proc[i].burst_time);
        proc[i].remaining_burst_time = proc[i].burst_time;
    }

    printf("Enter the time quantum: ");
    scanf("%d", &quantum);

    sort_by_arrival(proc, n);

    int arrivals_processed = 0;
    
    // Initial enqueue of processes that arrived at time 0
    for(int i = 0; i < n && proc[i].arrival_time <= current_time; i++) {
        enqueue(i);
        arrivals_processed++;
    }

    printf("\n\nRound Robin Scheduling Simulation\n");
    printf("\n-------------------Gantt Chart-------------------\n");

    while (completed_processes < n) {
        int process_index;
        
        if (is_queue_empty()) {
            // Find the next arriving process and fast-forward time
            int next_arrival_time = -1;
            for(int i = arrivals_processed; i < n; i++) {
                if (next_arrival_time == -1 || proc[i].arrival_time < next_arrival_time) {
                    next_arrival_time = proc[i].arrival_time;
                }
            }
            if (next_arrival_time != -1 && next_arrival_time > current_time) {
                 printf("| IDLE (%d-%d) ", current_time, next_arrival_time);
                 current_time = next_arrival_time;
            }

            // Enqueue all processes that have arrived by the new current time
            for(int i = arrivals_processed; i < n && proc[i].arrival_time <= current_time; i++) {
                enqueue(i);
                arrivals_processed++;
            }

            if (is_queue_empty()) {
                break; // No more processes
            }
        }

        process_index = dequeue();
        int burst_slice = (proc[process_index].remaining_burst_time > quantum) ? quantum : proc[process_index].remaining_burst_time;
        int start_time = current_time;

        current_time += burst_slice;
        proc[process_index].remaining_burst_time -= burst_slice;
        
        printf("| P%d (%d-%d) ", proc[process_index].pid, start_time, current_time);

        // Enqueue any new processes that arrived during this time slice
        for(int i = arrivals_processed; i < n && proc[i].arrival_time <= current_time; i++) {
            enqueue(i);
            arrivals_processed++;
        }

        if (proc[process_index].remaining_burst_time == 0) {
            // Process finished
            proc[process_index].completion_time = current_time;
            proc[process_index].turnaround_time = proc[process_index].completion_time - proc[process_index].arrival_time;
            proc[process_index].waiting_time = proc[process_index].turnaround_time - proc[process_index].burst_time;
            
            total_tat += proc[process_index].turnaround_time;
            total_wt += proc[process_index].waiting_time;
            completed_processes++;
        } else {
            // Process not finished, put back in queue
            enqueue(process_index);
        }
    }

    printf("|\n-------------------------------------------------\n");

    // Print results table
    printf("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time\n");
    for (int i = 0; i < n; i++) {
        printf("P%d\t%d\t\t%d\t\t%d\t\t%d\n", proc[i].pid, proc[i].arrival_time,
               proc[i].burst_time, proc[i].waiting_time, proc[i].turnaround_time);
    }
    
    // Print average times
    printf("\nAverage Waiting Time: %.2f\n", total_wt / n);
    printf("Average Turnaround Time: %.2f\n", total_tat / n);

    return 0;
}