#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MAX_LINE_LEN 80
#define MAX_ARGS 10

// Function to handle the 'typeline -n filename' command
void handle_typeline_command(char **args) {
    if (args[1] == NULL || args[2] == NULL || args[3] == NULL || strcmp(args[1], "-n") != 0) {
        fprintf(stderr, "myshell$: Usage: typeline -n <number_of_lines> <filename>\n");
        return;
    }

    int n_lines = atoi(args[2]);
    if (n_lines <= 0) {
        fprintf(stderr, "myshell$: Number of lines must be a positive integer.\n");
        return;
    }

    FILE *file = fopen(args[3], "r");
    if (file == NULL) {
        perror("myshell$: Could not open file");
        return;
    }

    char line_buffer[MAX_LINE_LEN];
    int line_count = 0;
    while (fgets(line_buffer, sizeof(line_buffer), file) != NULL && line_count < n_lines) {
        printf("%s", line_buffer);
        line_count++;
    }

    fclose(file);
}

int main(void) {
    char line[MAX_LINE_LEN];
    char *args[MAX_ARGS];
    pid_t pid;
    int status;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(line, MAX_LINE_LEN, stdin) == NULL) {
            break; // Exit on EOF (Ctrl+D)
        }
        
        // Remove the trailing newline character
        line[strcspn(line, "\n")] = 0;

        // Tokenize the input line
        char *token = strtok(line, " ");
        int i = 0;
        while (token != NULL && i < MAX_ARGS - 1) {
            args[i++] = token;
            token = strtok(NULL, " ");
        }
        args[i] = NULL; // Null-terminate the argument list

        if (args[0] == NULL) {
            continue; // Handle empty commands
        }
        
        // Handle built-in 'exit' command
        if (strcmp(args[0], "exit") == 0) {
            exit(0);
        }

        // Check for the custom 'typeline' command
        if (strcmp(args[0], "typeline") == 0) {
            handle_typeline_command(args);
            continue;
        }

        // Create a child process for external commands
        pid = fork();
        if (pid < 0) {
            perror("myshell$: fork failed");
        } else if (pid == 0) {
            // Child process: execute the command
            execvp(args[0], args);
            // This line is only reached if execvp fails
            perror("myshell$: Command not found");
            exit(1);
        } else {
            // Parent process: wait for the child to finish
            waitpid(pid, &status, 0);
        }
    }
    return 0;
}