#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>

using namespace std;

struct Process {
    int id;
    int arrival_time;
    int burst_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
};

// Sort by arrival time first, then by burst time
bool compareProcesses(const Process& a, const Process& b) {
    if (a.arrival_time != b.arrival_time) {
        return a.arrival_time < b.arrival_time;
    }
    return a.burst_time < b.burst_time;
}

int main() {
    int num_processes;
    cout << "Enter number of processes: ";
    cin >> num_processes;

    vector<Process> processes(num_processes);
    cout << "Enter arrival time and burst time for each process:" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].id = i + 1;
        cout << "Process " << processes[i].id << " Arrival Time: ";
        cin >> processes[i].arrival_time;
        cout << "Process " << processes[i].id << " Burst Time: ";
        cin >> processes[i].burst_time;
    }

    sort(processes.begin(), processes.end(), compareProcesses);

    vector<bool> is_completed(num_processes, false);
    int current_time = 0;
    int completed_processes = 0;
    
    cout << "\n---------------------Gantt Chart---------------------" << endl;
    
    while (completed_processes < num_processes) {
        int shortest_job_index = -1;
        int min_burst = 99999;

        // Find the shortest job that has arrived and is not completed
        for (int i = 0; i < num_processes; ++i) {
            if (!is_completed[i] && processes[i].arrival_time <= current_time) {
                if (processes[i].burst_time < min_burst) {
                    min_burst = processes[i].burst_time;
                    shortest_job_index = i;
                }
            }
        }

        if (shortest_job_index == -1) {
            // No process is ready, increment time
            current_time++;
            continue;
        }

        int idx = shortest_job_index;
        
        // Execute the selected process
        cout << " | P" << processes[idx].id << " |";
        current_time += processes[idx].burst_time;
        processes[idx].completion_time = current_time;
        is_completed[idx] = true;
        completed_processes++;
    }
    
    cout << "\n-----------------------------------------------------" << endl;

    double total_turnaround_time = 0;
    double total_waiting_time = 0;

    cout << "\nResults:" << endl;
    cout << "Process\tArrival\tBurst\tCompletion\tTurnaround\tWaiting" << endl;
    for (int i = 0; i < num_processes; ++i) {
        processes[i].turnaround_time = processes[i].completion_time - processes[i].arrival_time;
        processes[i].waiting_time = processes[i].turnaround_time - processes[i].burst_time;

        total_turnaround_time += processes[i].turnaround_time;
        total_waiting_time += processes[i].waiting_time;

        cout << processes[i].id << "\t" << processes[i].arrival_time << "\t" << processes[i].burst_time << "\t"
             << processes[i].completion_time << "\t\t" << processes[i].turnaround_time << "\t\t"
             << processes[i].waiting_time << endl;
    }

    cout << fixed << setprecision(2);
    cout << "\nAverage Turnaround Time: " << total_turnaround_time / num_processes << endl;
    cout << "Average Waiting Time: " << total_waiting_time / num_processes << endl;

    return 0;
}