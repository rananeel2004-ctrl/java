#include <stdio.h>
#define MAX 20

int main() {
    int n_frames, i, j, k;
    int frames[MAX], ref_string[MAX] = {7,5,4,8,5,7,2,3,1,3,5,9,4,6,2};
    int ref_len = 15;
    int page_faults = 0;

    printf("Enter number of frames: ");
    scanf("%d", &n_frames);

    // Initialize frames to -1 (empty)
    for (i = 0; i < n_frames; i++)
        frames[i] = -1;

    printf("\nReference String:\n");
    for (i = 0; i < ref_len; i++)
        printf("%d ", ref_string[i]);
    printf("\n\nPage Replacement Process (Optimal):\n");

    for (i = 0; i < ref_len; i++) {
        int current_page = ref_string[i];
        int found = 0;

        // Check if page is already in frame
        for (j = 0; j < n_frames; j++) {
            if (frames[j] == current_page) {
                found = 1; // Page hit
                break;
            }
        }

        // Page fault occurs
        if (!found) {
            int replace_index = -1;

            // Check for empty frame
            for (j = 0; j < n_frames; j++) {
                if (frames[j] == -1) {
                    replace_index = j;
                    break;
                }
            }

            // If no empty frame, use Optimal algorithm
            if (replace_index == -1) {
                int farthest = -1, index = -1;

                for (j = 0; j < n_frames; j++) {
                    int next_use = ref_len; // default if page not used again
                    for (k = i + 1; k < ref_len; k++) {
                        if (frames[j] == ref_string[k]) {
                            next_use = k;
                            break;
                        }
                    }
                    if (next_use > farthest) {
                        farthest = next_use;
                        index = j;
                    }
                }
                replace_index = index;
            }

            frames[replace_index] = current_page;
            page_faults++;
        }

        // Print current frame status
        printf("After page %2d: ", current_page);
        for (k = 0; k < n_frames; k++) {
            if (frames[k] != -1)
                printf("%2d ", frames[k]);
            else
                printf("-- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
