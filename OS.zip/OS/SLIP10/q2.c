#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>

#define MAX 256

// Function to implement 'list' command
void list_command(char *option, char *dirname) {
    DIR *dir;
    struct dirent *entry;

    dir = opendir(dirname);
    if (dir == NULL) {
        printf("Error: Cannot open directory %s\n", dirname);
        return;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_name[0] == '.')  // skip hidden files
            continue;

        if (strcmp(option, "f") == 0) {
            printf("%s\n", entry->d_name);
        } else if (strcmp(option, "i") == 0) {
            printf("%lu %s\n", (unsigned long)entry->d_ino, entry->d_name);
        } else {
            printf("Invalid option. Use 'f' or 'i'.\n");
            break;
        }
    }

    closedir(dir);
}

int main() {
    char input[MAX], *args[10];
    int i;
    pid_t pid;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL)
            break;

        input[strcspn(input, "\n")] = '\0';  // remove newline

        if (strlen(input) == 0)
            continue;

        // Exit command
        if (strcmp(input, "exit") == 0)
            break;

        // Tokenize input
        i = 0;
        args[i] = strtok(input, " ");
        while (args[i] != NULL)
            args[++i] = strtok(NULL, " ");

        // Handle 'list' command
        if (args[0] && strcmp(args[0], "list") == 0) {
            if (args[1] && args[2])
                list_command(args[1], args[2]);
            else
                printf("Usage: list [f|i] dirname\n");
            continue;
        }

        // Fork to execute other commands
        pid = fork();
        if (pid < 0) {
            printf("Error: Fork failed\n");
        } else if (pid == 0) {
            if (execvp(args[0], args) == -1)
                printf("Command not found: %s\n", args[0]);
            exit(0);
        } else {
            wait(NULL);  // Parent waits
        }
    }

    return 0;
}
