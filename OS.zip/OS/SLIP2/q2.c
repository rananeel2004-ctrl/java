#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>

#define MAX 100

// Function to implement 'list' command
void list_command(char *option, char *dirname) {
    DIR *d;
    struct dirent *dir;
    int count = 0;

    d = opendir(dirname);
    if (d == NULL) {
        printf("Error: Cannot open directory %s\n", dirname);
        return;
    }

    if (strcmp(option, "f") == 0) {
        // Print all file names
        while ((dir = readdir(d)) != NULL) {
            if (dir->d_type == DT_REG)  // Regular files only
                printf("%s\n", dir->d_name);
        }
    } else if (strcmp(option, "n") == 0) {
        // Count all entries
        while ((dir = readdir(d)) != NULL) {
            count++;
        }
        printf("Total entries in %s = %d\n", dirname, count);
    } else {
        printf("Invalid option for list. Use 'f' or 'n'\n");
    }

    closedir(d);
}

int main() {
    char input[MAX], *args[10];
    int i;
    pid_t pid;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(input, sizeof(input), stdin) == NULL)
            break;

        input[strcspn(input, "\n")] = '\0'; // remove newline

        if (strlen(input) == 0)
            continue;

        // Exit command
        if (strcmp(input, "exit") == 0)
            break;

        // Tokenize input
        i = 0;
        args[i] = strtok(input, " ");
        while (args[i] != NULL)
            args[++i] = strtok(NULL, " ");

        // Handle 'list' command
        if (args[0] && strcmp(args[0], "list") == 0) {
            if (args[1] && args[2])
                list_command(args[1], args[2]);
            else
                printf("Usage: list f dirname OR list n dirname\n");
            continue;
        }

        // Fork to execute other commands
        pid = fork();
        if (pid < 0) {
            printf("Error: Fork failed\n");
        } else if (pid == 0) {
            if (execvp(args[0], args) == -1)
                printf("Command not found: %s\n", args[0]);
            exit(0);
        } else {
            wait(NULL);  // Parent waits
        }
    }

    return 0;
}
