#include <stdio.h>

#define MAX 20

int main() {
    int n_frames, i, j, k;
    int frames[MAX], ref_string[MAX] = {3,4,5,6,3,4,7,3,4,5,6,7,2,4,6};
    int ref_len = 15;
    int page_faults = 0, next_to_replace = 0, found;

    printf("Enter number of frames: ");
    scanf("%d", &n_frames);

    // Initialize frames to -1 (empty)
    for (i = 0; i < n_frames; i++)
        frames[i] = -1;

    printf("\nReference String:\n");
    for (i = 0; i < ref_len; i++)
        printf("%d ", ref_string[i]);
    printf("\n\nPage Replacement Process (FIFO):\n");

    // Process each page in reference string
    for (i = 0; i < ref_len; i++) {
        found = 0;

        // Check if page is already in frames
        for (j = 0; j < n_frames; j++) {
            if (frames[j] == ref_string[i]) {
                found = 1; // Page hit
                break;
            }
        }

        // Page fault occurs
        if (!found) {
            frames[next_to_replace] = ref_string[i];
            next_to_replace = (next_to_replace + 1) % n_frames; // FIFO rotation
            page_faults++;
        }

        // Print current frame status
        printf("After page %2d: ", ref_string[i]);
        for (k = 0; k < n_frames; k++) {
            if (frames[k] != -1)
                printf("%2d ", frames[k]);
            else
                printf("-- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
