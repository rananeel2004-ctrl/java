#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>

#define MAX_LINE 1024
#define MAX_ARGS 64

// Function to handle the custom 'count' command
void count_file(char *option, char *filename) {
    FILE *file;
    int count = 0;
    char ch;
    int in_word = 0;

    file = fopen(filename, "r");
    if (file == NULL) {
        perror("Error opening file");
        return;
    }

    if (strcmp(option, "c") == 0) {
        // Count characters
        while ((ch = fgetc(file)) != EOF) {
            count++;
        }
        printf("Number of characters: %d\n", count);
    } else if (strcmp(option, "w") == 0) {
        // Count words
        while ((ch = fgetc(file)) != EOF) {
            if (isspace(ch)) {
                in_word = 0;
            } else if (in_word == 0) {
                in_word = 1;
                count++;
            }
        }
        printf("Number of words: %d\n", count);
    } else if (strcmp(option, "l") == 0) {
        // Count lines
        while ((ch = fgetc(file)) != EOF) {
            if (ch == '\n') {
                count++;
            }
        }
        printf("Number of lines: %d\n", count);
    } else {
        printf("Invalid option for 'count'. Use c, w, or l.\n");
    }

    fclose(file);
}

int main() {
    char line[MAX_LINE];
    char *args[MAX_ARGS];
    pid_t pid;

    while (1) {
        printf("myshell$ ");
        fflush(stdout);

        if (fgets(line, MAX_LINE, stdin) == NULL) {
            break; // Handle Ctrl+D
        }

        // Tokenize the input string
        int i = 0;
        args[i] = strtok(line, " \n");
        while (args[i] != NULL) {
            i++;
            args[i] = strtok(NULL, " \n");
        }

        if (args[0] == NULL) {
            continue;
        }

        // Handle internal 'exit' command
        if (strcmp(args[0], "exit") == 0 || strcmp(args[0], "quit") == 0) {
            break;
        }

        // Handle custom 'count' command
        if (strcmp(args[0], "count") == 0) {
            if (i == 3) {
                count_file(args[1], args[2]);
            } else {
                printf("Usage: count <c|w|l> <filename>\n");
            }
            continue; // Go to the next prompt
        }

        // Execute external commands
        pid = fork();
        if (pid < 0) {
            perror("fork failed");
            exit(1);
        } else if (pid == 0) {
            // Child process
            execvp(args[0], args);
            perror("execvp failed"); // execvp returns only on error
            exit(1);
        } else {
            // Parent process
            wait(NULL);
        }
    }

    return 0;
}