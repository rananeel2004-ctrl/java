#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

// Function for Bubble Sort
void bubbleSort(int arr[], int n) {
    int i, j, temp;
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

// Function for Insertion Sort
void insertionSort(int arr[], int n) {
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = arr[i];
        j = i - 1;
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j = j - 1;
        }
        arr[j + 1] = key;
    }
}

void printArray(int arr[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n, i;

    printf("Enter the number of integers: ");
    scanf("%d", &n);

    int *arr = (int *)malloc(n * sizeof(int));
    if (arr == NULL) {
        perror("Memory allocation failed");
        return 1;
    }

    printf("Enter %d integers: ", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        free(arr);
        return 1;
    } else if (pid == 0) {
        // Child process
        printf("\nChild process (PID: %d) is sorting with Insertion Sort...\n", getpid());
        insertionSort(arr, n);
        printf("Child process sorted array: ");
        printArray(arr, n);
    } else {
        // Parent process
        printf("\nParent process (PID: %d) is sorting with Bubble Sort...\n", getpid());
        bubbleSort(arr, n);
        printf("Parent process sorted array: ");
        printArray(arr, n);

        printf("\nParent process is waiting for child to finish...\n");
        wait(NULL); // Wait for the child process to terminate
        printf("Child process has terminated.\n");
    }

    free(arr);
    return 0;
}