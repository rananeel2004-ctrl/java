#include <stdio.h>
#define MAX 20

int main() {
    int n_frames, i, j, k;
    int frames[MAX], counter[MAX];
    int ref_string[MAX] = {8,5,7,8,5,7,2,3,7,3,5,9,4,6,2};
    int ref_len = 15;
    int page_faults = 0;

    printf("Enter number of frames: ");
    scanf("%d", &n_frames);

    // Initialize frames and counters
    for (i = 0; i < n_frames; i++) {
        frames[i] = -1;
        counter[i] = 0;
    }

    printf("\nReference String:\n");
    for (i = 0; i < ref_len; i++)
        printf("%d ", ref_string[i]);
    printf("\n\nPage Replacement Process (LRU using counter):\n");

    for (i = 0; i < ref_len; i++) {
        int current_page = ref_string[i];
        int found = 0;

        // Increment counters
        for (j = 0; j < n_frames; j++) {
            if (frames[j] != -1)
                counter[j]++;
        }

        // Check if page is already in frame
        for (j = 0; j < n_frames; j++) {
            if (frames[j] == current_page) {
                counter[j] = 0;  // Reset counter for this page
                found = 1;
                break;
            }
        }

        // Page fault occurs
        if (!found) {
            int replace_index = 0;
            int max_counter = -1;

            // Find page with max counter (least recently used)
            for (j = 0; j < n_frames; j++) {
                if (frames[j] == -1) { // empty frame found
                    replace_index = j;
                    break;
                }
                if (counter[j] > max_counter) {
                    max_counter = counter[j];
                    replace_index = j;
                }
            }

            frames[replace_index] = current_page;
            counter[replace_index] = 0;
            page_faults++;
        }

        // Print frame status
        printf("After page %2d: ", current_page);
        for (k = 0; k < n_frames; k++) {
            if (frames[k] != -1)
                printf("%2d ", frames[k]);
            else
                printf("-- ");
        }
        printf("\n");
    }

    printf("\nTotal Page Faults = %d\n", page_faults);

    return 0;
}
